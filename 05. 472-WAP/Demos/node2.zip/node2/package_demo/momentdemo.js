var moment = require('moment');
console.log(moment().format("LLLL")); //Sunday, June 13, 2021 6:24 PM