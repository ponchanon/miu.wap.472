console.log('--fdfsdfsd--999999999-');

function foo() {
    console.log(1111111);
}
foo();
module.exports = function() {
    console.log('Hi..fdfdfdfs....');
}