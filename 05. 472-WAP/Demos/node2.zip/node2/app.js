const greet = require('./npm_demo');
greet();