const fs = require('fs');

const server = require('http').createServer();

server.on('request', (req, res) => {
    fs.createReadStream('index.html').pipe(res);
});

server.listen(8000, () => { console.log('listening on 8000') });