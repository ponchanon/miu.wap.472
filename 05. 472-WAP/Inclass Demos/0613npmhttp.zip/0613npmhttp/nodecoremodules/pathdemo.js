const path = require('path');


console.log(path.dirname('Buffer'));
console.log(path.dirname('C:/hello/world/0612NodeJSIntro/nexttick/'));

const filePath = path.join('..','user', 'resources', 'images', 'profile.png');
console.log(filePath);

console.log(__filename, __dirname);

