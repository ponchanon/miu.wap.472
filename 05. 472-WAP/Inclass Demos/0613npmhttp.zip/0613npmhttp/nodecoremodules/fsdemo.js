const fs = require('fs');
const path = require('path');
console.log('start');
const content = fs.readFileSync('readme.txt', 'utf8');
console.log(content);

fs.readFile(path.join(__dirname, 'hello.txt'), 'utf-8', function(err, data){
    console.log(data);
    
    fs.writeFile('hello.txt', data.replace('{name}', 'John Smith'), err =>{
        if(err){
            console.log(err);
        } else {
            console.log('write succesfully!');
        }
        

        fs.appendFile('hello.txt', "you're awesome", (err) => {

        });

    });
});



console.log('end');

