const moment = require('moment');
console.log(moment().format('LLLL'));
console.log('Hello');
console.log('word');