const http = require('http');
const fs = require('fs');

http.createServer((req, res) => {
    let url = req.url;
    console.log(url);
    if (url === '/') {
        res.end(fs.readFileSync('message.html', 'utf8'));
    } else if (url.includes('/message')) {
        const body = [];
        req.on('data', (chunk) => {
            // console.log(chunk);
            body.push(chunk);
        });

        req.on('end', () => {
            res.write(Buffer.concat(body).toString());
            res.end('Upload succesfully');
        });
        
    } else {
        res.end('404 Page not found');
    }

}).listen(3000, () => console.log('listening on 3000'));