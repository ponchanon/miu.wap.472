const res = require('./mypackage');
console.log(res);