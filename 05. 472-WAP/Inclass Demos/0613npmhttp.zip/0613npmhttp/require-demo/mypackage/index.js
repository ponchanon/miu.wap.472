module.exports = {
    fname: 'John',
    lname: 'Smith'
}