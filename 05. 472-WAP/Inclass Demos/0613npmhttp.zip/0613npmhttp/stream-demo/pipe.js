const fs = require('fs');
const path = require('path');

const readable = fs.createReadStream(path.join(__dirname, 'card.jpg'), {highWaterMark: 128 * 1024});
const writable = fs.createWriteStream(path.join(__dirname,'..', 'hello.jpg'));
readable.pipe(writable);