const http = require('http');
const fs = require('fs');
const path = require('path');

http.createServer((req, res) => {
    let html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf-8');
    html = html.replace('{username}', 'John');
    res.end(html);
}).listen(3000, function(){
    console.log('listening on 3000.')
});