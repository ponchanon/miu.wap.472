const http = require('http');

http.createServer((req, res) => {
    res.write(`<h1>Title</h1>`);
    res.write('Hi');
    res.end('Hello World');
}).listen(3000, function(){
    console.log('listening on 3000.')
});