const http = require('http');
const server = http.createServer();

server.on('request', (req, res) => {
    res.write(`<h1>Title</h1>`);
    res.write('Hi');
    res.end('Hello World');
});

server.listen(3000, function(){
    console.log('listening on 3000.')
});