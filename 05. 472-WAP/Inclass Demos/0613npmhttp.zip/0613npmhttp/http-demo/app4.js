const http = require('http');
const fs = require('fs');
const path = require('path');

http.createServer((req, res) => {
    
    fs.readFile(path.join(__dirname, 'index.html'), 'utf-8', function(err, data){
        let html = data.replace('{username}', 'John');
        res.end(html);
    });
   
}).listen(3000, function(){
    console.log('listening on 3000.')
});