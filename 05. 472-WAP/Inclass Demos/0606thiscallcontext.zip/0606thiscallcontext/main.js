"use strict";
function greeting(){
    console.log(this);
}

const user = {
    firstname: 'John',
    greeting
    // sayHi: function(){
    //     console.log(this);
    // }
}

greeting();
window.greeting();

user.greeting();
// user.sayHi();