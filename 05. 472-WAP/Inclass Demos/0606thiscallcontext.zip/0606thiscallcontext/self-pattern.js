const obj = {
    salute: "",
    greet: function () {
        const self = this;
        self.salute = "Hello";
        console.log(this.salute); //Hello

        const setFrench = function (newSalute) {           
            self.salute = newSalute;
        };
        // setFrench.bind(this, "Bonjour")();
        // setFrench.bind(obj, "Bonjour")();
        // setFrench.call(this, 'Bonjour');
        // setFrench.apply(this, ['Bonjour']);
        setFrench('Bonjour');
        
        console.log(self.salute); //Bonjour
    }
};

obj.greet();  //Bonjour??  --> Hello!!??
