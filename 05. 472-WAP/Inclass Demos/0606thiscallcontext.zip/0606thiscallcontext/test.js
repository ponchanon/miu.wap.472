const obj = {}
obj.salute = 'Hi';
console.log(obj);