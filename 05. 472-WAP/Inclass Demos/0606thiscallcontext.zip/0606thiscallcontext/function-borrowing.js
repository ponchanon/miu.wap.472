const user = {
    firstname: 'John',
    lastname: 'Smith',
    getFullName(){
        return `${this.firstname} ${this.lastname}`;
    }
}

function logMe(height, weight){
    return `${this.getFullName()}, ${height}, ${weight}`;
}

// const res = logMe('180cm', '75kg');
// console.log(res);
const res1 = logMe.bind(user, '180cm', '75kg')();
console.log(res1);
const res2 = logMe.apply(user, ['180cm', '75kg']);
console.log(res2);
const res3 = logMe.call(user, '180cm', '75kg');
console.log(res3);
