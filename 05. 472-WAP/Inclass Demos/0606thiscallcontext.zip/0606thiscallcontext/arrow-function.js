// "use strict";

// const group = {
//     title: 'CS472',
//     students: ['John', 'Edward', 'Jack', 'Hopkins'],
//     showList: function(){
//         console.log(this);
//         this.students.forEach(function(item) {
//             console.log(this);
//             console.log(`${this.title}, ${item}`);
//         });
//     }
// };

// group.showList();

// let x = 10;
// let y = 99;

// const point = {
//     x: 1,
//     y: 2,
//     add: function() { //method
//         return this.x + this.y;
//     }
// }

// console.log(point.add());

const foo = () => {
    console.log(this);
}

foo.call({x:1, y:2});

