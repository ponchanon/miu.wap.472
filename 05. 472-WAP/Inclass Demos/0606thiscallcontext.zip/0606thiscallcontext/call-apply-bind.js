// function foo(arg1, arg2){
//     console.log(this);
//     console.log('fooo');
//     console.log(arg1, arg2);
// }

// // foo(1,2);
// foo.call("hello", 123, 666, 888);
// foo.apply({x:1, y:2}, [777, 999, 333]);

// const newFoo = foo.bind({x:1, y:2}, '3333');
// newFoo({firstname: 'John', lastname: 'Smith'});
// newFoo(()=> {console.log("It's me!!")});
// newFoo();


const user = {
    firstname: 'John',
    sayHi: function(more){
        console.log(`${this.firstname} says Hi, ${more}`);
    }
}
// setTimeout(user.sayHi, 3000);
//1. Wrapper
setTimeout(()=> user.sayHi('More.....'), 3000);
// //2. call
setTimeout(() => user.sayHi.call(user, 'More.....'), 3000);
// // //3. apply
setTimeout(() => user.sayHi.apply(user, ['More.....']), 3000);
// //4. bind
setTimeout(user.sayHi.bind(user, 'More.....'), 3000);