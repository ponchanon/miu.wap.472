const countries = ['China', 'US', 'Canada', 'Ethiopia', 'Eitria', 'Egypt', 'Vietnam'];

const result = countries.filter(function(elem, index, arr) {
    return elem.includes('a');
}).map(function(elem){
        return elem.length
    })


console.log(result);

let res2 = countries
            .filter(elem => elem.includes('a'))
            .map(elem =>elem.length)
            .reduce((accu, current) => accu + current, 0);



let multiple = (n, m, l) => {
    return n * m * l;
}


function sum(x, y){
    return x + y;
}

const sum2 = (x, y) => {
    return x + y;
}

const sum3 = (x, y) => x + y;


const sum4 = () => {
    
}

const sum5 = arg => {

}

console.log(sum2(3, 4));