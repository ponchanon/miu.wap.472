function sum(x, y) {
    let result = x + y;
    // return result;
}

const res = sum(2);
console.log(res);

//function expression
let multiple = function (n, m, l){
    return n * m * l;
}
console.log(typeof multiple);
console.log(multiple(1, 2));
