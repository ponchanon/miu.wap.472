let str1 = 'Hello';
let str2 = "Hi";

let str3 = "John says: \"Hi\".";
let str4 = 'John says: "Hi".';
let str5 = "say: 'Hi' ";

let str6 = "abc    " +
    "dfdfadsf" + 
    "dfdfdfdfd";

let str7 = `
    erewrw
    erewr
    fasdf
    dafd
`;

let coursename = 'CS472';
let welcome = 'Welcome to ' + coursename;
let welcome2 = `Welcome to ${coursename}`;
console.log(welcome, welcome2);

console.log(welcome.length);