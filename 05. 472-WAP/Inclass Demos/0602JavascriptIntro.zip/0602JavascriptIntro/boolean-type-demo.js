if([1,2]) {
    console.log(true);
} else {
    console.log(false);
}

let x = 5;
console.log(!x);