console.log(5 > 7);
console.log(5 < "7");
console.log(5 == "5.0"); //only compare values
console.log(5 === "5.0"); //compare values and types
console.log('--------------');
console.log(5 > 'abc');
console.log(5 < 'abc');
console.log(5 == 'abc');
console.log(-1 > NaN); //Not a number