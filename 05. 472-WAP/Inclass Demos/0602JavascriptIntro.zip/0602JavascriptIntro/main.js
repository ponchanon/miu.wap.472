for(var i = 0; i < 5; i++){
    console.log(i);
}
console.log("outside loop: " + i);

// let m = 88;
// console.log(typeof m);
// m = 'John';
// console.log(typeof m);


// const username = 'CS472';
// username = 'John';
// console.log(username);