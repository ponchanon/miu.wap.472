for(let i = 0; i < 5; i++) {
    console.log(i);
}