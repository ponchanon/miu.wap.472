//function expression
const sum = function(num1, num2) {
    return num1 + num2;
}
// console.log(typeof sum);
console.log(sum(3, 4));



// console.log(foo());

// function foo(){ //function declaration
//     return 'Hi';
// }



// function foo(arg1, arg2){
//     //logic
//     return 1;
// }

// function bar(){
//     let i = 10;
//     // return i;
//     console.log('dfdfdf');
// }

// let result = bar();
// console.log(result);