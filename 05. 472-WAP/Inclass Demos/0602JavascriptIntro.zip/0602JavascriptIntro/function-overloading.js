function log() {
    console.log('No arguments!');
}

function log(x) {
    console.log(`1 arguments! ${x}`);
}

function log(x, y) {
    console.log(`2 arguments! ${x}, ${y}`);
}

log();
log(1);
log(2, 3);