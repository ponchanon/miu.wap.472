// let i = 0

// let j = 1

// console.log(i)

function foo(){
    return 
    ({
        x: 1,
        y: 2
    })
}


console.log(foo());
