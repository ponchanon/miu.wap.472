const arr1 = [1,2,3];
const str = 'Hello';
const arr2 = ['US', 'Canada', 'Some'];

const res = [...arr1, ...str, ...arr2];
console.log(res);

// [1,2,3,'H','e', 'l', 'l', 'o', 'US', 'Canada', 'Some']
