const i = 8;

const j = 9.8;

console.log(typeof i);
console.log(typeof j);

let res1 = 3 + 3 + "hello";
console.log(res1, typeof res1);

let res2 = 3 + "3";
console.log(res2, typeof res2);

let res3 = 3 * parseInt("4 jj");
console.log(res3, typeof res3);