const obj = {
    'x': 1,
    "y": 2,
    username: 'John',
    'my name': 'hi', //property name or atrribute name or filed name
    getUsername: function(){ //method
        return this.username;
    }
};

console.log(obj.getUsername());

console.log(obj);
obj.username = 'Edward';
console.log(obj);
console.log(typeof obj);


console.log('--------=============---------');

// dot notation
console.log(obj.x);
// console.log(obj.'my name');
console.log(obj.firstname);

//bracket notation
console.log(obj['x']);
console.log(obj["username"]);
console.log(obj['my name']);
console.log('----------------');

let x = 'y';
console.log(obj[x]);


function foo(){
    console.log('foo....');
}

foo();


