// console.log(arguments);

function sum() {
    console.log(arguments); //arguments is an object
    let sum = 0;
    for(let i = 0; i< arguments.length; i++){ //array-like object, but not an Array
        sum += arguments[i];
    }
    console.log(sum);
}

sum(1, 2, 3);
sum(3, 5, 6, 8, 9);
sum(8, 9, 8, 6, 9, 10)