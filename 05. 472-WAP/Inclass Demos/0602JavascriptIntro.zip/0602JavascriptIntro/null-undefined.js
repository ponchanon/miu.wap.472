const j = null;

let i;

console.log(j.length);
console.log(i.length); //TypeError
console.log(username); //Reference Error