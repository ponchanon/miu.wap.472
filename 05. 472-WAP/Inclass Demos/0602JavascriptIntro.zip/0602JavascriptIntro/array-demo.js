const numbers2 = [1, 2, 3, 4, 5];
const sum2 = numbers2.reduce(function(sum, elem, index, arr) {
    return sum + elem
}, 0);
console.log(sum2);

// const countries = ['China', 'US', 'Canada', 'Ethiopia', 'Eitria', 'Egypt', 'Vietnam'];

// const result = countries.filter(function(elem, index, arr) {
//     return elem.includes('a');
// })
//     .map(function(elem){
//         return elem.length
//     })
// console.log(result);


const arr = ['China', 'US', 'Canada'];
const result = arr.filter(function (a, b) {
    // console.log(more);
    console.log(a);
    //return undefined
    return true;
})
console.log(result);

// countries[9] = '';
// console.log(countries.length);

// const names = [];
// names.push('John 1');
// names.push('John 2');
// names.push('John 3');
// console.log(names);
// names.pop();
// console.log(names);

// const numbers = [1,2,3];
// numbers.shift();
// console.log(numbers);
// numbers.unshift(4);
// console.log(numbers);

// const arr = [1, 2, 3];
// arr[0] = 5;

// arr[6] = 'hi';

// console.log(arr);

// const arr2 = [1, true, {x: 1}, [1,2], 'hi'];
// console.log(arr2);
// const arr3 = [];
// arr3[0] = 1;
