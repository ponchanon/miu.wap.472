const str = 'abc';
// str = 124;

const obj = {
    firstname: 'John',
    lastname: 'Smith'
};

console.log(obj);
// obj = 124;
obj.firstname = 'Edward';
console.log(obj);

