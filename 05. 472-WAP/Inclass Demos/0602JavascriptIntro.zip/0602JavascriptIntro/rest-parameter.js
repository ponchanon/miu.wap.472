function sum(x, y, ...more) {
    // console.log(x, y);
    // console.log(more);
   let result = x + y +  more.filter(function(elem){
        return elem > 3
    }).reduce(function(accu, elem) {
        return accu + elem
    });
    console.log(result);
}

// sum();
sum(1, 2, 4, 5, 6, 7);
sum(4, 5, 6, 8, 9, 8, 9, 6);