// const numbers = [10, 50, 80, 90, 90, 8, 9, 8];

// let a = numbers[0];
// let b = numbers[1];

// [m, a, ,b] = numbers;

// console.log(a, b, m);

const person = {
    firstname: 'Edward',
    lastname: 'Smith',
    age: 20,
    gender: 'Male'
};


// let first = person.firstname;
// let last = person.lastname;

// // let { first, last } = person;
// let first = person.first;
// let last = person.last;
// console.log(first, last);

let { firstname:first, lastname:last } = person;
// let first = person.firstname;
// let last = person.lastname;


let { firstname, lastname, age: myage, gender: mygender } = person;
// let firstname = person.firstname;
// let lastname = person.lastname;
// let myage = person.age;
// let mygender = person.gender;
console.log(firstname, lastname);

console.log(person.age);
person.firstname = 99999;