"use strict";

function bar(){
    console.log(this);
}

bar();

function foo(){
    console.log(j);
    j = 10; //j into global, implied global
}
foo();

console.log(j);

