// function foo(){
//     console.log('foo...');
//     return function(){
//         console.log(11111);
//     }
// }
// setTimeout(foo(), 5000);


function sum(num1, num2){
   return num1 + num2;
}

setTimeout(sum, 5000, 2, 3, 5);
