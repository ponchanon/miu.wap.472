console.log('start');

setTimeout(()=> console.log('timeout'), 5000);

console.log('end');

for(let i = 0; i < 5; i++){
    console.log(i);
}
