let x = 1;

function foo(y){
    return function(z){
        return x + y + z;
    }
}

let result = foo(4);
console.dir(result);
// console.log(result(5));
