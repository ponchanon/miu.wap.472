const makeAdder = function(x) {
    return function(y){
        return x + y;
    }
}

const adder1 = makeAdder(1);
const adder3 = makeAdder(3);
const adder5 = makeAdder(5);

adder1(3);
adder3(5);

function general (a, b , x){
    return a * x + b;
}

function makeFunction(a, b){
    return function(x){
        return a * x + b;
    }
}

const FtoC = makeFunction(9/5, 32);
FtoC(10);
FtoC(20);

const dollarToyuan = makeFunction(6.5, 0);
dollarToyuan(100);
dollarToyuan(200);

const res1 = general(9/5, 32, 10);
const res2 = general(9/5, 32, 10);
const res3 = general(9/5, 32, 10);

const res4 = general(6.5, 0 , 100);