function foo(){
    var i = 10;
    console.log(i);
}
foo();

// console.log(i);

(function (){ //IIFE: Immediately Invoked Function Expression
    var j = 10;
    console.log('IIFE:' , j);
})();
console.log(j);