function foo(){
    var m = 88;
    console.log(i);
}
foo();


if(true){
    var i = 10;
} else {
    let j = 9;
}


// console.log(i);
// console.log(j);

//LE {outer: null, i: undefined, j: undefined}
//LE {outer: null, i:10, j: undefined}
