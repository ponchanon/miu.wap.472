const a = function (m) {
    console.log(m, x);
}

function b(arg1, arg2) {
    console.log(num1);
    const x = 10;
    var num1 = 90;
    a(10, 90, 99);
    console.log(arg1);
    console.log(x);
}

const x = 20;
console.log(str);
var str = 'hi';
b(50);