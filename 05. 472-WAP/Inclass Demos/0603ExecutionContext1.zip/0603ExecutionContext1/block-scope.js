let i  = 5;

if(i > 8) { //block
    let j = 10;
    var x = 9;
    console.log(j, x);
}

console.log(x);
console.log(j);

// function foo(){ //function 

// }