function b() {
    function a() {
        console.log(x);
    }
    a();
}
const x = 20;
b();
