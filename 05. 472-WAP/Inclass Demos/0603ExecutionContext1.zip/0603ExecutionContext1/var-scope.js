function foo(){
    var x = 10;

    if(true){ //block - scope
        let j = 90;
        var m = 99;
    }
    console.log(f);
}
foo();
// console.log(x);


// for(var i = 0; i < 5; i++){
//     console.log('inside loop ' + i);
// }

// console.log(i);

function foo(){
    var i = 10;
}

console.log(i);