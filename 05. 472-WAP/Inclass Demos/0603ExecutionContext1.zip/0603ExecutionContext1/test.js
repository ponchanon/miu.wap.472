const courses = {
    0: 'cs472',
    1: 'cs477',
    2: 'cs544',
    length: 3
};


for(let i = 0; i < courses.length; i++){
    console.log(courses[i]);
}