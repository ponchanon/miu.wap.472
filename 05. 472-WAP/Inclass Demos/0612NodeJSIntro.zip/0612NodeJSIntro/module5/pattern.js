const username = 'John';
const getName = function(){
    return username;
}

//module.exports = {}

// module.exports.getUsername = getName;
module.exports = {
    getName
}

//return module.exports;