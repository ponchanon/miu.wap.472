const p = require('./pattern');
console.log(p); //  {getUsername: fn}