setImmediate(()=>console.log('Immediate'));
setTimeout(()=>console.log('timeout'));
process.nextTick(()=>console.log('nexttick'));