const p = require('./person');
console.log(p); 

p.firstname = 'Edward';

require('./pattern');