class Person{
    constructor(firstname, lastname){
        this.firstname = firstname;
        this.lastname = lastname;
    }
    
    getName(){
        console.log(`${this.firstname} ${this.lastname}`);
    }
}

module.exports = new Person('John', 'Smith');