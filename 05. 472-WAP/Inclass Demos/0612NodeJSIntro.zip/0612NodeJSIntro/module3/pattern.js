const p = require('./person');
console.log(p);


