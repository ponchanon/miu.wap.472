const { getName } = require('./pattern');
console.log(getName());
// console.log(pattern.getName());