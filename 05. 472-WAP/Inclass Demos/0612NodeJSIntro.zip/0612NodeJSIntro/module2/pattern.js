
//module.exports  = {}

module.exports.getName =  function(){
    return "John Smith";
}


exports.getName = function(){
    return "Edward Jack";
}

// module.exports = {};



//return module.exports