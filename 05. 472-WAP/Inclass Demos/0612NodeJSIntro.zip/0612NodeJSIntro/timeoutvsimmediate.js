setImmediate(()=>console.log('Immediate'));
setTimeout(()=>console.log('timeout'));



