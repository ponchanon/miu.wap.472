module.exports = function(){
    console.log('John Smith');
}



//return module.exports