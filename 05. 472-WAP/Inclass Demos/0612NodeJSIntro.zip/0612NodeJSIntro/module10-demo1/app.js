var i = 10;

const hello = require('./hello');
console.log('this is result of require: ');
console.log(hello);
console.log(i);