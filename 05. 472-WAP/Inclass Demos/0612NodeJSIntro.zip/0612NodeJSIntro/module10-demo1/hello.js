var i = 99;
console.log('hello');

//return module.exports
module.exports = 123;