const Person = require('./person');
const p = new Person('John', 'Smith');

p.firstname = 'Edward';
console.log(p);

require('./pattern');