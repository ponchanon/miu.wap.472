const Person = require('./person');
const p = new Person('John', 'Smith');
console.log(p);


