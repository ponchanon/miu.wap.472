setTimeout(function() { console.log("world"); }, 2000); 
console.log("hello");
console.log(global);
console.log(module);